self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d20d76a2f061201ecafec7274749aedf",
    "url": "/index.html"
  },
  {
    "revision": "324cf95b6aa6257ef9e8",
    "url": "/static/js/2.40348a0c.chunk.js"
  },
  {
    "revision": "63748a42c768e6232479f8dd8348a100",
    "url": "/static/js/2.40348a0c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "762e75aa8cf7b9cccee3",
    "url": "/static/js/main.8fc96e5c.chunk.js"
  },
  {
    "revision": "0e903404fe668039b1a7",
    "url": "/static/js/runtime-main.2a78626f.js"
  },
  {
    "revision": "917060553948b6661cccd39698570c5e",
    "url": "/static/media/logo.91706055.svg"
  }
]);